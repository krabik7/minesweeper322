# -*- coding: utf-8 -*-
import pygame, random, os, sys


def terminate():
    pygame.quit()
    sys.exit()
    
    
def set_mode(d):
    global WIDTH, HEIGHT, MINES, LEFT, TOP, CELL_SIZE, MODE
    if d == 1:
        MODE = 1
        WIDTH = 9
        HEIGHT = 9
        MINES = 10
        CELL_SIZE = 55
    elif d == 2:
        MODE = 2
        WIDTH = 16
        HEIGHT = 16
        MINES = 40
        CELL_SIZE = 30
    elif d == 3:
        MODE = 3
        WIDTH = 30
        HEIGHT = 16
        MINES = 99
        CELL_SIZE = 30
    elif d == 0:
        MODE = 0
        WIDTH = SWIDTH
        HEIGHT = SHEIGHT
        MINES = SMINES
        CELL_SIZE = 30
    LEFT = (W - WIDTH * CELL_SIZE) // 2
    TOP = (H - HEIGHT * CELL_SIZE) // 2


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def drawrect(screen, x, y, w, h):
    screen.fill((222, 222, 222), (x, y, w, h))
    screen.fill((255, 255, 255), (x, y, 4, h - 2))
    screen.fill((255, 255, 255), (x, y, w - 2, 4))
    screen.fill((128, 128, 128), (x + 2, y + h - 4, w - 2, 4))
    screen.fill((128, 128, 128), (x + w - 4, y + 2, 4, h - 2))
    screen.fill((222, 222, 222), (x + 2, y + h - 4, 2, 2))
    screen.fill((222, 222, 222), (x + 2 - 4, y + 2, 2, 2))


class Minesweeper():
    def __init__(self, width, height, m):
        self.win = False
        self.lose = False
        self.width = width
        self.height = height
        self.board = [[-1] * width for _ in range(height)]
        self.left = 10
        self.top = 10
        self.cell_size = 30
        self.m = m
        self.mines_r = m
        self.f = True
    
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size
    
    def generate_mines(self, x0, y0):
        global timer
        c = 0
        while c < self.m:
            x = random.randint(0, self.width - 1)
            y = random.randint(0, self.height - 1)
            if self.board[y][x] == -1:
                if x in range(x0 - 1, x0 + 2) and y in range(y0 - 1, y0 + 2):
                    continue
                self.board[y][x] = 10
                c += 1
        timer = True
    
    def get_cell(self, mouse_pos):
        x = mouse_pos[0]
        y = mouse_pos[1]
        left = self.left
        top = self.top
        size = self.cell_size
        w = self.width
        h = self.height
        if x < left or y < top or x > left + size * w or y > top + size * h:
            return None
        else:
            return ((x - left) // size, (y - top) // size)
        
            
    def get_click(self, event, lbutton, rbutton):
        if self.lose or self.win:
            return
        coords = self.get_cell(event.pos)
        if coords != None:
            self.on_click(coords, event.button, lbutton, rbutton)    
    
    def on_click(self, cell_coords, button, lbutton, rbutton):
        x, y = cell_coords[0], cell_coords[1]
        if button == 1:
            if rbutton:
                self.check_cell(x, y)
            else:
                self.open_cell(x, y)
        elif button == 3:
            if lbutton:
                self.check_cell(x, y)
            else:
                self.set_flag(x, y)
    
    def open_cell(self, x, y):
        if self.f:
            self.f = False
            self.generate_mines(x, y)
        if self.board[y][x] == 10:
            self.blow_up(x, y)
            return
        if self.board[y][x] != -1:
            return
        n = 0
        for i in range(x - 1, x + 2):
            if i < 0 or i >= self.width:
                continue
            for j in range(y - 1, y + 2):
                if j < 0 or j >= self.height:
                    continue
                if self.board[j][i] == 10 or self.board[j][i] == 11:
                    n += 1
        self.board[y][x] = n
        if n == 0:
            for i in range(x - 1, x + 2):
                if i < 0 or i >= self.width:
                    continue
                for j in range(y - 1, y + 2):
                    if j < 0 or j >= self.height:
                        continue
                    self.open_cell(i, j)
        self.check_win()
    
    def check_win(self):
        for j in range(self.height):
            for i in range(self.width):
                if self.board[j][i] == -1 or self.board[j][i] == 9:
                    return
        self.win = True
    
    def check_cell(self, x, y):
        if self.board[y][x] in [-1, 9, 10, 11]:
            return
        n = 0
        for i in range(x - 1, x + 2):
            if i < 0 or i >= self.width:
                continue
            for j in range(y - 1, y + 2):
                if j < 0 or j >= self.height:
                    continue
                if self.board[j][i] == 9 or self.board[j][i] == 11:
                    n += 1
        if n != self.board[y][x]:
            return
        for i in range(x - 1, x + 2):
            if i < 0 or i >= self.width:
                continue
            for j in range(y - 1, y + 2):
                if j < 0 or j >= self.height:
                    continue
                if self.board[j][i] == -1 or self.board[j][i] == 10:
                    self.open_cell(i, j)
    
    def set_flag(self, x, y):
        if self.board[y][x] == -1:
            self.board[y][x] = 9
        elif self.board[y][x] == 10:
            self.board[y][x] = 11
        elif self.board[y][x] == 9:
            self.board[y][x] = -1
        elif self.board[y][x] == 11:
            self.board[y][x] = 10
    
    def blow_up(self, x, y):
        self.lose = True
        self.losex = x
        self.losey = y
        
    def render(self, screen):
        self.mines_r = self.m
        left = self.left
        top = self.top
        cell_size = self.cell_size
        width = self.width
        height = self.height
        drawrect(screen, left - 24, top - 24, width * cell_size + 48, height * cell_size + 48)
        screen.fill((255, 255, 255), (left + width * cell_size, top - 2, 4, height * cell_size + 6))
        screen.fill((255, 255, 255), (left - 2, top + height * cell_size, width * cell_size + 6, 4))
        screen.fill((128, 128, 128), (left - 4, top - 4, width * cell_size + 6, 4))
        screen.fill((128, 128, 128), (left - 4, top - 4, 4, height * cell_size + 6))
        screen.fill((222, 222, 222), (left - 2, top + height * cell_size, 2, 2))
        screen.fill((222, 222, 222), (left + width * cell_size, top - 2, 2, 2))        
        screen.fill((192, 192, 192), (left, top, cell_size * width, cell_size * height))
        for i in range(self.width):
            for j in range(self.height):
                if self.board[j][i] == 9 or self.board[j][i] == 11:
                    self.mines_r -= 1
                pygame.draw.rect(screen, (128, 128, 128),
                                 (left + i * cell_size, top + j * cell_size, cell_size, cell_size), 1)
                cell_x = left + i * cell_size
                cell_y = top + j * cell_size
                if self.board[j][i] in [-1, 9, 10, 11]:
                    cell = pygame.transform.scale(images[11], (cell_size, cell_size))
                    cell_x -= 1
                    cell_y -= 1
                else:
                    cell = pygame.transform.scale(images[self.board[j][i]], (cell_size, cell_size))                  
                if self.board[j][i] == 9 or self.board[j][i] == 11:
                    flag = pygame.transform.scale(images[9], (cell_size, cell_size))
                    cell.blit(flag, (1, 1))
                if self.lose:
                    if self.board[j][i] == 10 or self.board[j][i] == 11:
                        if i == self.losex and j == self.losey:
                            cell = pygame.Surface((cell_size, cell_size))
                            cell.fill((255, 0, 0))
                            cell.blit(pygame.transform.scale(images[10], (cell_size, cell_size)), (0, 0))
                        else:
                            cell = pygame.transform.scale(images[10], (cell_size, cell_size))
                        cell_x += 1
                        cell_y += 1
                screen.blit(cell, (cell_x, cell_y))

class Button(pygame.sprite.Sprite):
    def __init__(self, group, x, y, h, mi, ma):
        super().__init__(group)
        self.image = load_image("mmmkavo.png")
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.miny = y
        self.maxy = y - h
        self.value = mi
        self.mi = mi
        self.ma = ma
        self.h = h
    
    def set_value(self, value):
        if value > self.ma:
            value = self.ma
        elif value < self.mi:
            value = self.mi
        self.value = value
        self.rect.y = self.miny - int(self.h * (value - self.mi) / (self.ma - self.mi))
    
    def set_y(self, y):
        if y < self.maxy:
            y = self.maxy
        elif y > self.miny:
            y = self.miny
        self.rect.y = y
        self.value = self.mi + int((self.ma - self.mi) * (self.miny - y) / (self.miny - self.maxy))



def settings_screen():
    global SWIDTH, SHEIGHT, SMINES
    g1 = False
    g2 = False
    g3 = False    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONUP:
                g1 = False
                g2 = False
                g3 = False
                x, y = event.pos
                if x > 510 and x < 770 and y > 608 and y < 688:
                    return
                if x > 133 and x < 573:
                    if y > 150 and y < 276:
                        set_mode(1)
                    elif y > 307 and y < 433:
                        set_mode(2)
                    elif y > 464 and y < 590:
                        set_mode(3)
                elif x > 706 and x < 1146 and y > 150 and y < 590:
                    set_mode(0)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if wb.rect.collidepoint(event.pos):
                    g1 = True
                if hb.rect.collidepoint(event.pos):
                    g2 = True
                if mb.rect.collidepoint(event.pos):
                    g3 = True
            if event.type == pygame.MOUSEMOTION:
                if g1:
                    wb.set_y(event.pos[1])
                    SWIDTH = wb.value
                elif g2:
                    hb.set_y(event.pos[1])
                    SHEIGHT = hb.value
                elif g3:
                    mb.set_y(event.pos[1])
                    SMINES = mb.value
                if SMINES > (SWIDTH * SHEIGHT) // 2:
                    SMINES = (SWIDTH * SHEIGHT) // 2
                    mb.set_value(SMINES)
                if g1 or g2 or g3:
                    set_mode(0)
        mine = pygame.transform.scale(images[10], (90, 90))
        minex = 151
        miney = 168
        if MODE == 2:
            miney = 325
        elif MODE == 3:
            miney = 482
        elif MODE == 0:
            minex = 724
        screen.fill((224, 224, 224))
        drawrect(screen, 0, 0, W, H)
        font = pygame.font.Font(None, 70)
        text = font.render("УРОВЕНЬ:", 1, pygame.Color("black"))
        screen.blit(text, (520, 70))
        drawrect(screen, 133, 150, 440, 126)
        drawrect(screen, 133, 307, 440, 126)
        drawrect(screen, 133, 464, 440, 126)
        drawrect(screen, 706, 150, 440, 440)
        screen.fill((255, 255, 255), (W - 20, 18, 4, H - 34))
        screen.fill((255, 255, 255), (18, H - 20, W - 34, 4))
        screen.fill((128, 128, 128), (16, 16, 4, H - 34))
        screen.fill((128, 128, 128), (16, 16, W - 34, 4))
        screen.fill((222, 222, 222), (W - 20, 18, 2, 2))
        screen.fill((222, 222, 222), (18, H - 20, 2, 2))        
        font = pygame.font.Font(None, 55)
        text1 = font.render("Новичок", 1, pygame.Color("black"))
        text2 = font.render("Любитель", 1, pygame.Color("black"))
        text3 = font.render("Профессионал", 1, pygame.Color("black"))
        text4 = font.render("Особый", 1, pygame.Color("black"))
        text11 = font.render("9x9 10 мин", 1, pygame.Color("black"))
        text21 = font.render("16x16 40 мин", 1, pygame.Color("black"))
        text31 = font.render("16x30 99 мин", 1, pygame.Color("black"))
        text41 = font.render(str(SWIDTH) + "x" + str(SHEIGHT) + " " + str(SMINES) + " мин",
                             1, pygame.Color("black"))
        screen.blit(text1, (376, 168))
        screen.blit(text2, (356, 325))
        screen.blit(text3, (266, 482))
        screen.blit(text4, (949, 168))
        screen.blit(text11, (346, 213))
        screen.blit(text21, (306, 370))
        screen.blit(text31, (306, 527))
        screen.blit(text41, (859, 213))
        drawrect(screen, 510, 608, 260, 80)
        textok = font.render("OK", 1, pygame.Color("black"))
        screen.blit(textok, (611, 631))
        pygame.draw.rect(screen, (128, 128, 128), (919, 321, 15, 219), 2)
        screen.fill((128, 128, 128), (918, 320, 15, 2))
        screen.fill((128, 128, 128), (918, 320, 2, 219))
        pygame.draw.rect(screen, (128, 128, 128), (786, 321, 15, 219), 2)
        screen.fill((128, 128, 128), (785, 320, 15, 2))
        screen.fill((128, 128, 128), (785, 320, 2, 219))
        pygame.draw.rect(screen, (128, 128, 128), (1050, 321, 15, 219), 2)
        screen.fill((128, 128, 128), (1049, 320, 15, 2))
        screen.fill((128, 128, 128), (1049, 320, 2, 219))
        font = pygame.font.Font(None, 30)
        textw = font.render("Ряды", 1, pygame.Color("black"))
        texth = font.render("Столбцы", 1, pygame.Color("black"))
        textm = font.render("Мины", 1, pygame.Color("black"))
        textw1 = font.render(str(SWIDTH), 1, pygame.Color("black"))
        texth1 = font.render(str(SHEIGHT), 1, pygame.Color("black"))
        textm1 = font.render(str(SMINES), 1, pygame.Color("black"))
        screen.blit(textw, (767, 270))
        screen.blit(texth, (880, 270))
        screen.blit(textm, (1031, 270))
        screen.blit(textw1, (782, 295))
        screen.blit(texth1, (913, 295))
        screen.blit(textm1, (1046, 295))
        screen.blit(mine, (minex, miney))
        all_sprites.draw(screen)
        pygame.display.flip()
        clock.tick(FPS)


def new_game():
    global timer, time, a, rbutton, lbutton
    a = True
    timer = False
    lbutton = False
    rbutton = False    
    time = 0
    saper = Minesweeper(WIDTH, HEIGHT, MINES)
    saper.set_view(LEFT, TOP, CELL_SIZE)
    return saper


def win():
    c = 2
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEBUTTONUP:
                c -= 1
                if c == 0:
                    return
        drawrect(screen, 440, 210, 400, 300)
        font = pygame.font.Font(None, 70)
        win_text = font.render("Вы победили!", 1, pygame.Color("Black"))
        time_text = font.render("Время: " + str(int(time)), 1, pygame.Color("black"))
        screen.blit(win_text, (460, 230))
        screen.blit(time_text, (460, 380))
        pygame.display.flip()
        clock.tick(FPS)


pygame.init()
FPS = 120
size = W, H = 1280, 720
set_mode(2)
SWIDTH = WIDTH
SHEIGHT = HEIGHT
SMINES = MINES
screen = pygame.display.set_mode(size)
screen.fill((0, 0, 0))
pygame.display.flip()
clock = pygame.time.Clock()
running = True
images = [load_image('0.png', -1), load_image('1.png', -1), load_image('2.png', -1),
          load_image('3.png', -1), load_image('4.png', -1), load_image('5.png', -1), 
          load_image('6.png', -1), load_image('7.png', -1), load_image('8.png', -1), 
          load_image('flag.png', -1), load_image('mine.png', -1), load_image('cell.png')]
saper = new_game()
all_sprites = pygame.sprite.Group()
hb = Button(all_sprites, 902, 539, 220, 9, 16)
hb.set_value(SHEIGHT)
wb = Button(all_sprites, 769, 539, 220, 9, 30)
wb.set_value(SWIDTH)
mb = Button(all_sprites, 1033, 539, 220, 10, 240)
mb.set_value(SMINES)
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONUP:
            if event.pos[0] > 300 and event.pos[0] < 565\
               and event.pos[1] > 30 and event.pos[1] < 105:
                saper = new_game()
            if event.pos[0] > 715 and event.pos[0] < 980\
               and event.pos[1] > 30 and event.pos[1] < 105:
                settings_screen()
            saper.get_click(event, lbutton, rbutton)
            if event.button == 1:
                lbutton = False
            if event.button == 3:
                rbutton = False            
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                lbutton = True
            elif event.button == 3:
                rbutton = True
    drawrect(screen, 0, 0, W, H)
    screen.fill((255, 255, 255), (W - 20, 18, 4, H - 34))
    screen.fill((255, 255, 255), (18, H - 20, W - 34, 4))
    screen.fill((128, 128, 128), (16, 16, 4, H - 34))
    screen.fill((128, 128, 128), (16, 16, W - 34, 4))
    screen.fill((222, 222, 222), (W - 20, 18, 2, 2))
    screen.fill((222, 222, 222), (18, H - 20, 2, 2))
    drawrect(screen, 300, 30, 265, 55)
    drawrect(screen, 715, 30, 265, 55)
    font = pygame.font.Font(None, 50)
    new_game_text = font.render("Новая игра", 1, pygame.Color("black"))
    settings_text = font.render("Настройки", 1, pygame.Color("black"))
    screen.blit(new_game_text, (335, 40))
    screen.blit(settings_text, (755, 40))
    time_text = font.render("Время: " + str(int(time)), 1, pygame.Color("black"))
    mines_text = font.render("Осталось мин: " + str(saper.mines_r), 1, pygame.Color("black"))
    screen.blit(time_text, (335, 650))
    screen.blit(mines_text, (725, 650))
    saper.render(screen)
    pygame.display.flip()
    if saper.win and a:
        win()
        a = False
        timer = False
    elif saper.lose:
        timer = False
    clock.tick(FPS)
    if timer:
        time += 1 / FPS
terminate()
